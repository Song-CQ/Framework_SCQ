//
// Auto Generated Code By excel2json
// https://neil3d.gitee.io/coding/excel2json.html
// 1. 每个 Sheet 形成一个 Struct 定义, Sheet 的名称作为 Struct 的名称
// 2. 表格约定：第一行是变量名称，第二行是变量类型

// Generate From D:\MyGitHub\excel2json\Docs\ExampleData.xlsx.xlsx

public class NPC
{
	public string ID; // 编号
	public string Name; // 名称
	public string AssetName; // 资源编号
	public int HP; // 血
	public int Attack; // 攻击
	public int Defence; // 防御
	public date DateTest; // 测试日期
}

public class Item
{
	public string ID; // 编号
	public string Name; // 名称
	public string AssetName; // 资源编号
}


// End of Auto Generated Code
